# Wedding Cake Calculator (Vite + React + Tailwind)

Modern, sleek SPA (no Next.js) for estimating wedding cake costs and browsing nearby bakers.

## Run
```bash
npm install
npm run dev
```

Open http://localhost:5173

## What's inside
- Vite + React + TypeScript + Tailwind
- `src/WeddingCakeCalculator.tsx` (full estimator UI + logic)
- framer-motion animations & lucide-react icons
