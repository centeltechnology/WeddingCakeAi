import WeddingCakeCalculator from './WeddingCakeCalculator'

export default function App() {
  return (
    <div className="min-h-screen">
      <WeddingCakeCalculator />
    </div>
  )
}
