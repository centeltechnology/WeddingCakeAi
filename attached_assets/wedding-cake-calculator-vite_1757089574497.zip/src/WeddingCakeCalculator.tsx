
import React, { useMemo, useState } from "react";
import { Cake, MapPin, User, Printer, LocateFixed, MessageSquare, Send } from "lucide-react";
import { motion } from "framer-motion";

type Complexity = "simple" | "classic" | "luxury";

export default function WeddingCakeCalculator() {
  const PRICING = {
    servingsPricePerSlice: { simple: 5.0, classic: 7.0, luxury: 10.0 },
    servingsByTierInches: { 6: 12, 8: 24, 10: 38, 12: 56, 14: 78 },
    fillingsPerTier: 8,
    premiumFlavorUpchargePerServing: 0.75,
    dietaryUpchargePerServing: { glutenFree: 1.25, vegan: 1.5, nutFree: 0.5 },
    sugarFlowersPerStem: 6,
    metallicAccentsFlat: 45,
    customTopperFlat: 35,
    fondantFinishPerServing: 1.0,
    tastingKitFlat: 25,
    deliveryBase: 35,
    deliveryPerMile: 1.75,
    milesIncluded: 5,
    setupFeeFlat: 40,
    standRentalFlat: 25,
    rushPercent: 0.2,
    taxRate: 0.0825,
    orderMinimum: 250,
  } as const;

  const BAKERS = [
    { id: "tx-rosebakery", name: "Rose & Ribbon Cakes", city: "Tyler", state: "TX", zip: "75701", phone: "(903) 555-1020", email: "hello@roseandribbonevents.com", website: "https://example.com/rose", socials: { instagram: "roseandribboncakes" }, rating: 4.9, reviewCount: 61, lat: 32.321, lon: -95.301, maxMiles: 60 },
    { id: "tx-sweetforge", name: "SweetForge Studio", city: "Longview", state: "TX", zip: "75601", phone: "(430) 555-3388", email: "bookings@sweetforge.studio", website: "https://example.com/forge", socials: { instagram: "sweetforge.studio" }, rating: 4.7, reviewCount: 29, lat: 32.5, lon: -94.74, maxMiles: 40 },
    { id: "tx-gildedcrumb", name: "Gilded Crumb Patisserie", city: "Dallas", state: "TX", zip: "75201", phone: "(214) 555-9200", email: "contact@gildedcrumb.com", website: "https://example.com/gilded", socials: { instagram: "gildedcrumb" }, rating: 5.0, reviewCount: 103, lat: 32.781, lon: -96.8, maxMiles: 30 },
  ] as const;

  const [tab, setTab] = useState<"calculator" | "bakers" | "profile">("calculator");
  const [guestCount, setGuestCount] = useState<number>(120);
  const [tiers, setTiers] = useState<number[]>([6, 8, 10, 12]);
  const [complexity, setComplexity] = useState<Complexity>("classic");
  const [fondant, setFondant] = useState<boolean>(false);
  const [premiumFlavor, setPremiumFlavor] = useState<boolean>(false);
  const [fillings, setFillings] = useState<number>(2);
  const [dietary, setDietary] = useState<{glutenFree:boolean; vegan:boolean; nutFree:boolean}>({glutenFree:false, vegan:false, nutFree:false});
  const [sugarFlowerStems, setSugarFlowerStems] = useState<number>(6);
  const [metallicAccents, setMetallicAccents] = useState<boolean>(true);
  const [customTopper, setCustomTopper] = useState<boolean>(false);
  const [tastingKit, setTastingKit] = useState<boolean>(true);
  const [deliveryMiles, setDeliveryMiles] = useState<number>(18);
  const [setupOnsite, setSetupOnsite] = useState<boolean>(true);
  const [standRental, setStandRental] = useState<boolean>(false);
  const [rush, setRush] = useState<boolean>(false);

  const [profile, setProfile] = useState({ name: "", email: "", city: "", state: "TX", zip: "" });
  const [userCoordinates, setUserCoordinates] = useState<{lat:number; lon:number} | null>(null);

  function servingsFromTiers(ts: number[]) { return ts.reduce((sum, t) => sum + (PRICING.servingsByTierInches[t as keyof typeof PRICING.servingsByTierInches] || 0), 0); }
  const suggestedTiers = useMemo(() => { const all = [6,8,10,12,14]; let pick:number[] = []; let total=0; for (let i=0;i<all.length;i++) { if (total < guestCount) { pick.push(all[i]); total = servingsFromTiers(pick); } } return pick; }, [guestCount]);
  function formatCurrency(n:number){ return n.toLocaleString(undefined,{style:"currency",currency:"USD"}); }
  function calcDistanceMiles(a:{lat:number;lon:number}, b:{lat:number;lon:number}){ const toRad=(d:number)=>d*Math.PI/180; const R=3958.8; const dLat=toRad(b.lat-a.lat); const dLon=toRad(b.lon-a.lon); const lat1=toRad(a.lat); const lat2=toRad(b.lat); const h = Math.sin(dLat/2)**2 + Math.cos(lat1)*Math.cos(lat2)*Math.sin(dLon/2)**2; return 2*R*Math.asin(Math.sqrt(h)); }

  const estimate = useMemo(()=>{
    const servings = Math.max(servingsFromTiers(tiers), guestCount);
    const basePerServing = PRICING.servingsPricePerSlice[complexity];
    const lineItems: {label:string; amount:number; hint?:string}[] = [];

    const base = servings * basePerServing;
    lineItems.push({ label: `Base cake (${servings} servings @ ${formatCurrency(basePerServing)})`, amount: base});

    if (fondant) { const amt = servings * PRICING.fondantFinishPerServing; lineItems.push({label: `Fondant finish (${formatCurrency(PRICING.fondantFinishPerServing)}/serving)`, amount: amt}); }
    if (premiumFlavor) { const amt = servings * PRICING.premiumFlavorUpchargePerServing; lineItems.push({label: `Premium flavor upcharge (${formatCurrency(PRICING.premiumFlavorUpchargePerServing)}/serving)`, amount: amt}); }

    const dietKeys = Object.entries(dietary).filter(([_,v])=>v).map(([k])=>k as keyof typeof PRICING.dietaryUpchargePerServing);
    for (const key of dietKeys) { const per = PRICING.dietaryUpchargePerServing[key]; const amt = servings * per; lineItems.push({ label: `${key.replace(/([A-Z])/g," $1")} upcharge (${formatCurrency(per)}/serving)`, amount: amt}); }

    if (fillings>0){ const amt = fillings * PRICING.fillingsPerTier; lineItems.push({ label: `Additional filling layers (${fillings} total)`, amount: amt}); }
    if (sugarFlowerStems>0){ const amt = sugarFlowerStems * PRICING.sugarFlowersPerStem; lineItems.push({ label: `Handmade sugar flowers (${sugarFlowerStems} stems)`, amount: amt}); }
    if (metallicAccents){ lineItems.push({ label: `Edible metallic accents`, amount: PRICING.metallicAccentsFlat}); }
    if (customTopper){ lineItems.push({ label: `Custom topper`, amount: PRICING.customTopperFlat}); }

    if (tastingKit){ lineItems.push({ label: `Tasting kit`, amount: PRICING.tastingKitFlat}); }
    if (setupOnsite){ lineItems.push({ label: `On-site delivery & setup (base)`, amount: PRICING.deliveryBase + PRICING.setupFeeFlat}); } else { lineItems.push({ label: `Pickup prep (no setup)`, amount: 0}); }

    const extraMiles = Math.max(0, deliveryMiles - PRICING.milesIncluded);
    if (extraMiles>0){ lineItems.push({ label: `Delivery distance (${extraMiles} mi beyond ${PRICING.milesIncluded} included)`, amount: extraMiles * PRICING.deliveryPerMile}); }

    if (standRental){ lineItems.push({ label: `Stand rental (refundable if returned)`, amount: PRICING.standRentalFlat}); }

    const subtotal = lineItems.reduce((s,i)=>s+i.amount,0);
    const minAdj = Math.max(0, PRICING.orderMinimum - subtotal);
    if (minAdj>0){ lineItems.push({ label: `Minimum order adjustment`, amount: minAdj, hint: `(Order minimum ${formatCurrency(PRICING.orderMinimum)})`}); }

    let totalBeforeRush = subtotal + minAdj;
    let rushAmt = 0;
    if (rush){ rushAmt = totalBeforeRush * PRICING.rushPercent; lineItems.push({ label: `Rush fee (${Math.round(PRICING.rushPercent*100)}%)`, amount: rushAmt}); }

    const taxable = totalBeforeRush + rushAmt;
    const tax = taxable * PRICING.taxRate;
    const grand = taxable + tax;

    return { lineItems, servings, subtotal: totalBeforeRush, tax, total: grand };
  }, [tiers, guestCount, complexity, fondant, premiumFlavor, dietary, fillings, sugarFlowerStems, metallicAccents, customTopper, tastingKit, deliveryMiles, setupOnsite, standRental, rush]);

  const suggestedServings = useMemo(()=>servingsFromTiers(suggestedTiers),[suggestedTiers]);
  const currentServings = useMemo(()=>servingsFromTiers(tiers),[tiers]);

  function useNearbyBakers(){
    const [radius, setRadius] = useState<number>(50);
    const results = useMemo(()=>{
      if (!userCoordinates) return [] as typeof BAKERS;
      return BAKERS.filter(b => calcDistanceMiles(userCoordinates, {lat:b.lat, lon:b.lon}) <= Math.min(radius, b.maxMiles));
    }, [userCoordinates, radius]);
    return { radius, setRadius, results };
  }
  const nearby = useNearbyBakers();

  function locateMe(){
    if (!navigator.geolocation){
      alert("Geolocation not supported in your browser.");
      return;
    }
    navigator.geolocation.getCurrentPosition((pos)=>{
      setUserCoordinates({ lat: pos.coords.latitude, lon: pos.coords.longitude });
      setTab("bakers");
    }, ()=>{
      alert("Location permission denied. You can still filter by city/zip in a full app.");
    });
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white text-slate-800">
      <header className="border-b border-slate-200 bg-white/60 backdrop-blur sticky top-0 z-20">
        <div className="mx-auto max-w-6xl px-6 py-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-slate-900 text-white shadow-sm"><Cake className="h-5 w-5"/></div>
            <div>
              <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight">Wedding Cake Calculator</h1>
              <p className="text-xs sm:text-sm text-slate-600">Plan servings, design options, and find bakers near you.</p>
            </div>
          </div>
          <nav className="flex gap-2">
            {["calculator","bakers","profile"].map((t)=> (
              <button key={t} onClick={()=>setTab(t as any)}
                className={`px-4 py-2 rounded-full text-sm font-medium border transition-all shadow-sm ${tab===t? "bg-slate-900 text-white" : "bg-white hover:bg-slate-50"}`}>{t[0].toUpperCase()+t.slice(1)}</button>
            ))}
          </nav>
        </div>
      </header>

      {tab==="calculator" && (
        <main className="mx-auto max-w-6xl px-6 py-8 grid md:grid-cols-2 gap-6">
          <motion.section initial={{opacity:0, y:8}} animate={{opacity:1,y:0}} transition={{duration:0.35}} className="space-y-4">
            <div className="p-5 bg-white rounded-2xl shadow-sm ring-1 ring-slate-200">
              <h2 className="text-lg font-semibold mb-3">Guest Count & Tiers</h2>
              <div className="grid grid-cols-2 gap-3">
                <label className="text-sm">Guests
                  <input type="number" value={guestCount} onChange={e=>setGuestCount(Math.max(0, parseInt(e.target.value||"0")))}
                    className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 outline-none focus:ring-2 focus:ring-slate-400"/>
                </label>
                <label className="text-sm">Design complexity
                  <select value={complexity} onChange={e=>setComplexity(e.target.value as Complexity)}
                    className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 outline-none focus:ring-2 focus:ring-slate-400">
                    <option value="simple">Simple</option>
                    <option value="classic">Classic</option>
                    <option value="luxury">Luxury</option>
                  </select>
                </label>
              </div>

              <div className="mt-3">
                <div className="text-sm font-medium mb-1">Selected tiers (inches)</div>
                <div className="flex flex-wrap gap-2">
                  {[6,8,10,12,14].map((s)=>{
                    const active = tiers.includes(s);
                    return (
                      <button key={s} onClick={()=>setTiers(prev => active ? prev.filter(p=>p!==s) : [...prev, s].sort((a,b)=>a-b))}
                        className={`px-3 py-1 rounded-full border text-sm transition ${active ? "bg-slate-900 text-white" : "bg-white hover:bg-slate-50"}`}>{s}"</button>
                    );
                  })}
                </div>
                <div className="mt-2 text-xs text-slate-600">Servings from tiers: <strong>{currentServings}</strong> · Suggested for {guestCount} guests: <button className="underline" onClick={()=>setTiers(suggestedTiers)}>{suggestedTiers.join(" • ")}"</button> (<span>{suggestedServings} servings</span>)</div>
              </div>
            </div>

            <div className="p-5 bg-white rounded-2xl shadow-sm ring-1 ring-slate-200">
              <h2 className="text-lg font-semibold mb-3">Flavors & Dietary</h2>
              <div className="grid sm:grid-cols-3 gap-3 text-sm">
                <label className="flex items-center gap-2"><input type="checkbox" checked={premiumFlavor} onChange={e=>setPremiumFlavor(e.target.checked)}/> Premium flavor</label>
                <label className="flex items-center gap-2"><input type="checkbox" checked={fondant} onChange={e=>setFondant(e.target.checked)}/> Fondant finish</label>
                <label className="flex items-center gap-2"><input type="checkbox" checked={dietary.glutenFree} onChange={e=>setDietary({...dietary, glutenFree:e.target.checked})}/> Gluten-free</label>
                <label className="flex items-center gap-2"><input type="checkbox" checked={dietary.vegan} onChange={e=>setDietary({...dietary, vegan:e.target.checked})}/> Vegan</label>
                <label className="flex items-center gap-2"><input type="checkbox" checked={dietary.nutFree} onChange={e=>setDietary({...dietary, nutFree:e.target.checked})}/> Nut-free</label>
                <label className="text-sm">Extra filling layers
                  <input type="number" min={0} value={fillings} onChange={e=>setFillings(Math.max(0, parseInt(e.target.value||"0")))}
                    className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 outline-none focus:ring-2 focus:ring-slate-400"/>
                </label>
              </div>
            </div>

            <div className="p-5 bg-white rounded-2xl shadow-sm ring-1 ring-slate-200">
              <h2 className="text-lg font-semibold mb-3">Decor & Logistics</h2>
              <div className="grid sm:grid-cols-3 gap-3 text-sm">
                <label className="text-sm">Sugar flower stems
                  <input type="number" min={0} value={sugarFlowerStems} onChange={e=>setSugarFlowerStems(Math.max(0, parseInt(e.target.value||"0")))}
                    className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 outline-none focus:ring-2 focus:ring-slate-400"/>
                </label>
                <label className="flex items-center gap-2"><input type="checkbox" checked={metallicAccents} onChange={e=>setMetallicAccents(e.target.checked)}/> Metallic accents</label>
                <label className="flex items-center gap-2"><input type="checkbox" checked={customTopper} onChange={e=>setCustomTopper(e.target.checked)}/> Custom topper</label>
                <label className="flex items-center gap-2"><input type="checkbox" checked={tastingKit} onChange={e=>setTastingKit(e.target.checked)}/> Tasting kit</label>
                <label className="text-sm">Delivery miles
                  <input type="number" min={0} value={deliveryMiles} onChange={e=>setDeliveryMiles(Math.max(0, parseInt(e.target.value||"0")))}
                    className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 outline-none focus:ring-2 focus:ring-slate-400"/>
                </label>
                <label className="flex items-center gap-2"><input type="checkbox" checked={setupOnsite} onChange={e=>setSetupOnsite(e.target.checked)}/> On-site setup</label>
                <label className="flex items-center gap-2"><input type="checkbox" checked={standRental} onChange={e=>setStandRental(e.target.checked)}/> Stand rental</label>
                <label className="flex items-center gap-2"><input type="checkbox" checked={rush} onChange={e=>setRush(e.target.checked)}/> Rush order</label>
              </div>
            </div>
          </motion.section>

          <motion.section initial={{opacity:0, y:8}} animate={{opacity:1,y:0}} transition={{duration:0.35}} className="p-5 bg-white rounded-2xl shadow-sm ring-1 ring-slate-200 flex flex-col">
            <h2 className="text-lg font-semibold mb-1">Your Estimate</h2>
            <div className="text-sm text-slate-600 mb-3">Transparent, itemized pricing based on your selections.</div>

            <div className="flex-1 overflow-auto rounded-xl border border-slate-200 bg-slate-50">
              <ul className="divide-y divide-slate-200">
                {estimate.lineItems.map((li, idx)=> (
                  <li key={idx} className="p-3 flex items-start justify-between gap-3">
                    <div className="text-sm">
                      <div className="font-medium">{li.label}</div>
                      {li.hint && <div className="text-xs text-slate-600">{li.hint}</div>}
                    </div>
                    <div className="text-sm font-semibold">{formatCurrency(li.amount)}</div>
                  </li>
                ))}
              </ul>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
              <div className="p-3 bg-white rounded-xl border border-slate-200 flex items-center justify-between"><span>Subtotal</span><strong>{formatCurrency(estimate.subtotal)}</strong></div>
              <div className="p-3 bg-white rounded-xl border border-slate-200 flex items-center justify-between"><span>Sales Tax</span><strong>{formatCurrency(estimate.tax)}</strong></div>
              <div className="col-span-2 p-3 bg-slate-900 text-white rounded-xl flex items-center justify-between text-base"><span>Total</span><strong>{formatCurrency(estimate.total)}</strong></div>
              <div className="col-span-2 text-xs text-slate-600">This is an estimate, not a binding quote. Final price depends on design review, availability, and contract.</div>
            </div>

            <div className="mt-4 flex flex-wrap gap-2">
              <button className="px-4 py-2 rounded-xl bg-slate-900 text-white flex items-center gap-2" onClick={()=>window.print()}><Printer className="h-4 w-4"/> Print / Save PDF</button>
              <button className="px-4 py-2 rounded-xl border border-slate-200 flex items-center gap-2" onClick={()=>setTab("bakers")}><MapPin className="h-4 w-4"/> Find Bakers Near Me</button>
            </div>
          </motion.section>
        </main>
      )}

      {tab==="bakers" && (
        <main className="mx-auto max-w-6xl px-6 py-8 grid lg:grid-cols-3 gap-6">
          <section className="lg:col-span-1 p-5 bg-white rounded-2xl shadow-sm ring-1 ring-slate-200">
            <h2 className="text-lg font-semibold mb-2">Find Bakers Near You</h2>
            <p className="text-sm text-slate-600">Use your location to see nearby bakers. (Demo list only.)</p>
            <div className="mt-3 flex gap-2">
              <button className="px-4 py-2 rounded-xl bg-slate-900 text-white flex items-center gap-2" onClick={locateMe}><LocateFixed className="h-4 w-4"/> Use my location</button>
              <button className="px-4 py-2 rounded-xl border border-slate-200" onClick={()=>setUserCoordinates(null)}>Clear</button>
            </div>
            <div className="mt-4">
              <label className="text-sm">Radius (miles)
                <input type="range" min={5} max={100} step={5} value={nearby.radius} onChange={(e)=>nearby.setRadius(parseInt(e.target.value))} className="w-full"/>
              </label>
              <div className="text-xs text-slate-600">Showing within {nearby.radius} miles {userCoordinates?"" : "(set your location)"}.</div>
            </div>
          </section>
          <section className="lg:col-span-2 space-y-3">
            {(userCoordinates? nearby.results : BAKERS).map(b => (
              <motion.div key={b.id} initial={{opacity:0, y:6}} animate={{opacity:1,y:0}} transition={{duration:0.25}} className="p-5 bg-white rounded-2xl shadow-sm ring-1 ring-slate-200">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="text-base font-semibold">{b.name}</div>
                    <div className="text-sm text-slate-600">{b.city}, {b.state} • {b.zip}</div>
                    <div className="text-sm mt-1">⭐ {b.rating} ({b.reviewCount} reviews)</div>
                  </div>
                  <div className="text-right text-sm">
                    <div><a className="underline" href={`tel:${b.phone}`}>{b.phone}</a></div>
                    <div><a className="underline" href={`mailto:${b.email}`}>{b.email}</a></div>
                    <div>{b.website && <a className="underline" href={b.website} target="_blank" rel="noreferrer">Website ↗</a>}</div>
                    {b.socials?.instagram && <div className="text-xs text-slate-600">IG: @{b.socials.instagram}</div>}
                    {userCoordinates && (<div className="text-xs text-slate-600 mt-1">~{calcDistanceMiles(userCoordinates, {lat:b.lat, lon:b.lon}).toFixed(1)} mi away</div>)}
                  </div>
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  <button className="px-3 py-1 rounded-lg border border-slate-200 flex items-center gap-2"><Send className="h-4 w-4"/> Request quote</button>
                  <button className="px-3 py-1 rounded-lg border border-slate-200 flex items-center gap-2"><MessageSquare className="h-4 w-4"/> Message baker</button>
                  <button className="px-3 py-1 rounded-lg border border-slate-200" onClick={()=>setTab("calculator")}>Match to my estimate</button>
                </div>
              </motion.div>
            ))}
            {userCoordinates && (nearby.results.length===0) && (
              <div className="p-5 bg-white rounded-2xl shadow-sm ring-1 ring-slate-200 text-sm">No bakers within the selected radius. Try expanding your search.</div>
            )}
          </section>
        </main>
      )}

      {tab==="profile" && (
        <main className="mx-auto max-w-6xl px-6 py-8 grid md:grid-cols-2 gap-6">
          <section className="p-5 bg-white rounded-2xl shadow-sm ring-1 ring-slate-200">
            <h2 className="text-lg font-semibold mb-2 flex items-center gap-2"><User className="h-5 w-5"/> My Profile</h2>
            <div className="grid sm:grid-cols-2 gap-3 text-sm">
              <label>Name<input className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2" value={profile.name} onChange={e=>setProfile({...profile, name:e.target.value})}/></label>
              <label>Email<input className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2" value={profile.email} onChange={e=>setProfile({...profile, email:e.target.value})}/></label>
              <label>City<input className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2" value={profile.city} onChange={e=>setProfile({...profile, city:e.target.value})}/></label>
              <label>State<input className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2" value={profile.state} onChange={e=>setProfile({...profile, state:e.target.value})}/></label>
              <label>ZIP<input className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2" value={profile.zip} onChange={e=>setProfile({...profile, zip:e.target.value})}/></label>
            </div>
            <div className="mt-4 text-xs text-slate-600">In a full app, this profile lets you save quotes, message bakers, and manage bookings.</div>
          </section>

          <section className="p-5 bg-white rounded-2xl shadow-sm ring-1 ring-slate-200">
            <h2 className="text-lg font-semibold mb-2">Share Your Estimate</h2>
            <p className="text-sm text-slate-600">Send your itemized estimate to selected bakers. (Demo only.)</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {BAKERS.map(b=> (
                <button key={b.id} className="px-3 py-1 rounded-lg border border-slate-200">Send to {b.name.split(" ")[0]}</button>
              ))}
            </div>
            <div className="mt-4 text-xs text-slate-600">You’ll receive replies at your profile email.</div>
          </section>
        </main>
      )}

      <footer className="px-6 pb-10 mt-8 text-center text-xs text-slate-500">
        <div>© {new Date().getFullYear()} Wedding Cake Calculator • Demo</div>
      </footer>
    </div>
  );
}
