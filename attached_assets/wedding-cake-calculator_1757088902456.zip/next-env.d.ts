/// <reference types="next" />
/// <reference types="next/navigation-types/compat/navigation" />
/// <reference types="next/image-types/global" />

// NOTE: This file should not be edited
