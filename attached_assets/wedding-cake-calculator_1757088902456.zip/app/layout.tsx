import "./../styles/globals.css";

export const metadata = {
  title: "Wedding Cake Calculator",
  description: "Estimate your wedding cake and find bakers near you."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
