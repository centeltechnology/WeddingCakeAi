import WeddingCakeCalculator from "@/components/WeddingCakeCalculator";

export default function Page(){
  return (
    <div className="min-h-screen">
      <WeddingCakeCalculator />
    </div>
  );
}
