# Wedding Cake Calculator

Modern, sleek React + Tailwind web app that lets brides estimate wedding cake pricing and discover bakers nearby.

---

## ✨ Features
- **Itemized estimator**: guest count → suggested tiers; complexity (simple/classic/luxury); fondant; premium flavors; dietary options; decorations; delivery/setup; rush; minimums; tax; print-to-PDF.
- **Baker finder (demo)**: mock directory with distance filtering and geolocation.
- **Profile (demo)**: save basic contact info and “share estimate” UI.
- **Clean UI**: Tailwind, rounded cards, subtle borders, generous spacing; framer‑motion animations; lucide-react icons.

> Pricing values are placeholders. Adjust them in the `PRICING` config block inside the component.

---

## 🧱 Tech Stack
- **Frontend**: Next.js (App Router) + React + TailwindCSS
- **Animation & Icons**: framer‑motion, lucide-react
- **Deploy**: Vercel (recommended)

---

## 📁 Project Structure
```
/
├─ app/
│  ├─ layout.tsx
│  └─ page.tsx          # renders <WeddingCakeCalculator />
├─ components/
│  └─ WeddingCakeCalculator.tsx
├─ styles/
│  └─ globals.css
├─ tailwind.config.ts
├─ postcss.config.js
├─ tsconfig.json
├─ package.json
└─ next.config.mjs
```

---

## 🚀 Quick Start
```bash
# 1) Install
npm install

# 2) Dev
npm run dev

# 3) Open
# http://localhost:3000
```

### Deploy
- Push to GitHub and import into Vercel. No server functions required for this demo.

---

## ⚙️ Environment (future server features)
Create `.env.local` as you add features:
```
DATABASE_URL=postgres://user:pass@host:5432/wcc
NEXTAUTH_SECRET=your_generated_secret
STRIPE_SECRET_KEY=sk_...
STRIPE_WEBHOOK_SECRET=whsec_...
AWS_REGION=us-east-1
AWS_SES_SENDER=hello@yourdomain.com
GOOGLE_MAPS_API_KEY=...
YELP_API_KEY=...
```

---

## 🧮 Tuning Prices
Open the component and edit the `PRICING` block:
- Per‑serving base by complexity tier
- Servings per tier size
- Add‑ons (fondant, premium flavor, dietary upcharges, flowers, metallics, topper)
- Logistics (tasting kit, delivery, setup, stand rental)
- Minimum order, rush %, tax rate

---

## 🗺️ Baker Directory (real data later)
Start with mock data, then switch to real sources (manual onboarding, Google Places, Yelp Fusion). Label third‑party ratings clearly and follow attribution rules.

---

## 💸 Monetization Ideas
- Baker subscriptions (Free / Pro / Plus)
- Per‑lead fees
- Optional bride premium tools

---

**Name**: Wedding Cake Calculator
